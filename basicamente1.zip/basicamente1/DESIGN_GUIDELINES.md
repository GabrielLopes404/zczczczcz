# Diretrizes de Design - LUCREI

## Design Tokens

### Espaçamentos Padrão
- **Extra Small (xs)**: 0.5rem (8px) - Espaços internos mínimos
- **Small (sm)**: 1rem (16px) - Espaçamento padrão entre elementos relacionados
- **Medium (md)**: 1.5rem (24px) - Espaçamento entre seções dentro de um card
- **Large (lg)**: 2rem (32px) - Espaçamento entre seções principais
- **Extra Large (xl)**: 3rem (48px) - Espaçamento entre grandes blocos de conteúdo

### Breakpoints Responsivos
- **Mobile**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: ≥ 1024px
- **Wide Desktop**: ≥ 1280px

### Hierarquia Tipográfica
- **H1**: text-3xl sm:text-4xl lg:text-5xl - Títulos de página principal
- **H2**: text-2xl sm:text-3xl - Títulos de seção
- **H3**: text-xl sm:text-2xl - Subtítulos
- **Body**: text-sm sm:text-base - Texto padrão
- **Small**: text-xs sm:text-sm - Texto auxiliar

## Componentes de Layout

### PageContainer
- Padding horizontal: px-4 sm:px-6 lg:px-8
- Espaçamento vertical entre elementos: space-y-6
- Max width: max-w-7xl mx-auto

### Cards
- Padding: p-4 sm:p-6
- Border radius: rounded-xl
- Shadow: shadow-sm
- Border: border border-border

### Formulários
- Labels: text-sm font-medium mb-2
- Inputs: h-10 px-3
- Espaçamento entre campos: space-y-4
- Botões de ação: Alinhados à direita em desktop, full-width em mobile

### Grids Responsivos
- 1 coluna em mobile (< 640px)
- 2 colunas em tablet (≥ 640px)
- 3-4 colunas em desktop (≥ 1024px)

## Princípios de Responsividade

1. **Mobile First**: Começar com layout mobile e adicionar complexidade
2. **Flexbox/Grid**: Usar flex e grid para layouts flexíveis
3. **Truncate Long Text**: Usar truncate ou line-clamp para textos longos
4. **Stack on Mobile**: Elementos lado a lado em desktop devem empilhar em mobile
5. **Hidden Elements**: Ocultar elementos não essenciais em mobile (sm:block)

## Checklist de Revisão de Página

- [ ] Container principal tem max-width e padding responsivo
- [ ] Espaçamento vertical consistente (space-y-*)
- [ ] Títulos seguem hierarquia tipográfica
- [ ] Formulários são responsivos (empilham em mobile)
- [ ] Tabelas têm scroll horizontal em mobile
- [ ] Botões têm tamanho apropriado para touch (min 44px)
- [ ] Textos longos não quebram layout
- [ ] Imagens são responsivas
- [ ] Modais/Dialogs funcionam em mobile
- [ ] Navegação funciona em mobile (menu hamburger)

## Estados de Interface

### Empty States
- Ícone centralizado
- Título descritivo
- Texto explicativo
- Call-to-action claro

### Loading States
- Skeleton loaders para conteúdo
- Spinners para ações
- Desabilitar botões durante carregamento

### Error States
- Mensagem clara do erro
- Sugestão de ação
- Botão para tentar novamente
