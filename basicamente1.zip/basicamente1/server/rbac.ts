import { Request, Response, NextFunction } from "express";
import { User } from "@shared/schema";

// Extend Express Request to include user
declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

// RBAC Middleware - Check if user has required role
export function requireRole(roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: "Não autenticado" });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        message: "Acesso negado. Você não tem permissão para acessar este recurso." 
      });
    }

    next();
  };
}

// Specific role checkers
export const requireCustomer = requireRole(["CUSTOMER", "ADMIN", "OWNER"]);
export const requireAdmin = requireRole(["ADMIN", "OWNER"]);
export const requireOwner = requireRole(["OWNER"]);

// Check if user can manage another user
export function canManageUser(currentUser: User, targetUserRole: string): boolean {
  // OWNER can manage anyone
  if (currentUser.role === "OWNER") {
    return true;
  }

  // ADMIN can manage CUSTOMER but not other ADMIN or OWNER
  if (currentUser.role === "ADMIN") {
    return targetUserRole === "CUSTOMER";
  }

  return false;
}

// Check if user can access resource from organization
export function requireOrganizationAccess(req: Request, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ message: "Não autenticado" });
  }

  if (!req.user.organizationId) {
    return res.status(403).json({ message: "Usuário não pertence a uma organização" });
  }

  next();
}

// Log user action to audit logs
export async function logAudit(params: {
  db: any;
  userId: string;
  organizationId?: string | null;
  action: string;
  entityType?: string;
  entityId?: string;
  oldValue?: any;
  newValue?: any;
  ipAddress?: string;
  userAgent?: string;
}) {
  const { db, userId, organizationId, action, entityType, entityId, oldValue, newValue, ipAddress, userAgent } = params;
  
  try {
    const { auditLogs } = await import("@shared/schema");
    
    await db.insert(auditLogs).values({
      userId,
      organizationId,
      action,
      entityType,
      entityId,
      oldValue: oldValue ? JSON.stringify(oldValue) : null,
      newValue: newValue ? JSON.stringify(newValue) : null,
      ipAddress,
      userAgent,
    });
  } catch (error) {
    console.error("Failed to log audit:", error);
  }
}
