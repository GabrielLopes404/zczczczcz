import { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { storage } from "./storage";

export function generateApiKey(): string {
  return `lucrei_${crypto.randomBytes(32).toString("hex")}`;
}

export async function validateApiKey(req: Request, res: Response, next: NextFunction) {
  const apiKey = req.headers["x-api-key"] as string;

  if (!apiKey) {
    return res.status(401).json({ message: "API key required" });
  }

  if (!apiKey.startsWith("lucrei_")) {
    return res.status(401).json({ message: "Invalid API key format" });
  }

  try {
    const hashedKey = crypto.createHash("sha256").update(apiKey).digest("hex");
    const keyRecord = await storage.getApiKeyByHash(hashedKey);

    if (!keyRecord || !keyRecord.isActive) {
      return res.status(401).json({ message: "Invalid or inactive API key" });
    }

    if (keyRecord.expiresAt && new Date(keyRecord.expiresAt) < new Date()) {
      return res.status(401).json({ message: "API key expired" });
    }

    await storage.updateApiKeyLastUsed(keyRecord.id);

    req.user = {
      id: keyRecord.userId,
      username: "",
      email: "",
      organizationId: keyRecord.organizationId,
      role: "ADMIN",
    };

    next();
  } catch (error) {
    console.error("API key validation error:", error);
    res.status(500).json({ message: "Authentication failed" });
  }
}
