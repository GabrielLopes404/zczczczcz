import { Request, Response, NextFunction } from "express";
import { db } from "./db";
import { organizations, users, customers, transactions, subscriptions } from "@shared/schema";
import { eq, and, count, sql } from "drizzle-orm";

// Define os limites de cada plano
export const PLAN_LIMITS = {
  starter: {
    maxUsers: 2,
    maxCustomers: 100,
    maxTransactionsPerMonth: 500,
    features: {
      reports: "basic",
      api: false,
      automation: false,
      prioritySupport: false,
      customizations: false,
    },
  },
  business: {
    maxUsers: 10,
    maxCustomers: -1, // ilimitado
    maxTransactionsPerMonth: -1, // ilimitado
    features: {
      reports: "advanced",
      api: true,
      automation: true,
      prioritySupport: true,
      customizations: false,
    },
  },
  enterprise: {
    maxUsers: -1, // ilimitado
    maxCustomers: -1, // ilimitado
    maxTransactionsPerMonth: -1, // ilimitado
    features: {
      reports: "advanced",
      api: true,
      automation: true,
      prioritySupport: true,
      customizations: true,
    },
  },
};

type PlanType = "starter" | "business" | "enterprise";

// Verifica se o plano está ativo e não expirado
export async function checkPlanStatus(organizationId: string): Promise<{
  isActive: boolean;
  isTrialing: boolean;
  daysLeft: number;
  planType: PlanType;
  status: string;
}> {
  // Buscar organização
  const [org] = await db
    .select()
    .from(organizations)
    .where(eq(organizations.id, organizationId))
    .limit(1);

  if (!org) {
    throw new Error("Organization not found");
  }

  // Buscar assinatura ativa
  const [subscription] = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.organizationId, organizationId))
    .orderBy(sql`${subscriptions.createdAt} DESC`)
    .limit(1);

  // Se não tem assinatura, está no trial
  if (!subscription) {
    // Calcular dias desde criação da organização
    const createdAt = new Date(org.createdAt);
    const now = new Date();
    const daysSinceCreation = Math.floor((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24));
    const trialDays = 7;
    const daysLeft = Math.max(0, trialDays - daysSinceCreation);

    return {
      isActive: daysLeft > 0,
      isTrialing: true,
      daysLeft,
      planType: "starter",
      status: daysLeft > 0 ? "trialing" : "expired",
    };
  }

  // Verificar status da assinatura
  const isActive = ["active", "trialing"].includes(subscription.status);
  const isTrialing = subscription.status === "trialing";

  // Calcular dias restantes do trial
  let daysLeft = 0;
  if (isTrialing && subscription.currentPeriodEnd) {
    const now = new Date();
    const endDate = new Date(subscription.currentPeriodEnd);
    daysLeft = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  }

  return {
    isActive,
    isTrialing,
    daysLeft,
    planType: (subscription.planType as PlanType) || "starter",
    status: subscription.status,
  };
}

// Middleware para verificar se o plano está ativo
export function requireActivePlan() {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !req.user.organizationId) {
      return res.status(401).json({ message: "Não autenticado" });
    }

    try {
      const planStatus = await checkPlanStatus(req.user.organizationId);

      if (!planStatus.isActive) {
        return res.status(403).json({
          message: "Sua assinatura expirou. Por favor, renove seu plano para continuar usando o sistema.",
          code: "SUBSCRIPTION_EXPIRED",
          trialExpired: true,
        });
      }

      // Anexar informações do plano ao request para uso posterior
      (req as any).planStatus = planStatus;
      next();
    } catch (error) {
      console.error("Error checking plan status:", error);
      return res.status(500).json({ message: "Erro ao verificar status do plano" });
    }
  };
}

// Verifica se pode criar mais usuários
export async function canCreateUser(organizationId: string): Promise<{ allowed: boolean; limit: number; current: number }> {
  const [org] = await db
    .select()
    .from(organizations)
    .where(eq(organizations.id, organizationId))
    .limit(1);

  if (!org) {
    throw new Error("Organization not found");
  }

  const planType = (org.planType as PlanType) || "starter";
  const limits = PLAN_LIMITS[planType];

  // Se o limite é -1 (ilimitado), sempre permitir
  if (limits.maxUsers === -1) {
    return { allowed: true, limit: -1, current: 0 };
  }

  // Contar usuários atuais
  const [result] = await db
    .select({ count: count() })
    .from(users)
    .where(eq(users.organizationId, organizationId));

  const currentUsers = result?.count || 0;

  return {
    allowed: currentUsers < limits.maxUsers,
    limit: limits.maxUsers,
    current: currentUsers,
  };
}

// Verifica se pode criar mais clientes
export async function canCreateCustomer(organizationId: string): Promise<{ allowed: boolean; limit: number; current: number }> {
  const [org] = await db
    .select()
    .from(organizations)
    .where(eq(organizations.id, organizationId))
    .limit(1);

  if (!org) {
    throw new Error("Organization not found");
  }

  const planType = (org.planType as PlanType) || "starter";
  const limits = PLAN_LIMITS[planType];

  // Se o limite é -1 (ilimitado), sempre permitir
  if (limits.maxCustomers === -1) {
    return { allowed: true, limit: -1, current: 0 };
  }

  // Contar clientes atuais
  const [result] = await db
    .select({ count: count() })
    .from(customers)
    .where(eq(customers.organizationId, organizationId));

  const currentCustomers = result?.count || 0;

  return {
    allowed: currentCustomers < limits.maxCustomers,
    limit: limits.maxCustomers,
    current: currentCustomers,
  };
}

// Verifica se pode criar mais transações este mês
export async function canCreateTransaction(organizationId: string): Promise<{ allowed: boolean; limit: number; current: number }> {
  const [org] = await db
    .select()
    .from(organizations)
    .where(eq(organizations.id, organizationId))
    .limit(1);

  if (!org) {
    throw new Error("Organization not found");
  }

  const planType = (org.planType as PlanType) || "starter";
  const limits = PLAN_LIMITS[planType];

  // Se o limite é -1 (ilimitado), sempre permitir
  if (limits.maxTransactionsPerMonth === -1) {
    return { allowed: true, limit: -1, current: 0 };
  }

  // Calcular primeiro e último dia do mês atual
  const now = new Date();
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

  // Contar transações do mês atual
  const [result] = await db
    .select({ count: count() })
    .from(transactions)
    .where(
      and(
        eq(transactions.organizationId, organizationId),
        sql`${transactions.date} >= ${firstDay}`,
        sql`${transactions.date} <= ${lastDay}`
      )
    );

  const currentTransactions = result?.count || 0;

  return {
    allowed: currentTransactions < limits.maxTransactionsPerMonth,
    limit: limits.maxTransactionsPerMonth,
    current: currentTransactions,
  };
}

// Verifica se uma feature está disponível para o plano
export function hasFeature(planType: PlanType, feature: keyof typeof PLAN_LIMITS.starter.features): boolean {
  const limits = PLAN_LIMITS[planType];
  return !!limits.features[feature];
}

// Middleware para verificar feature específica
export function requireFeature(feature: keyof typeof PLAN_LIMITS.starter.features) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !req.user.organizationId) {
      return res.status(401).json({ message: "Não autenticado" });
    }

    try {
      const [org] = await db
        .select()
        .from(organizations)
        .where(eq(organizations.id, req.user.organizationId))
        .limit(1);

      if (!org) {
        return res.status(404).json({ message: "Organização não encontrada" });
      }

      const planType = (org.planType as PlanType) || "starter";

      if (!hasFeature(planType, feature)) {
        return res.status(403).json({
          message: `Esta funcionalidade não está disponível no seu plano atual. Faça upgrade para acessar.`,
          code: "FEATURE_NOT_AVAILABLE",
          feature,
          currentPlan: planType,
        });
      }

      next();
    } catch (error) {
      console.error("Error checking feature:", error);
      return res.status(500).json({ message: "Erro ao verificar funcionalidade" });
    }
  };
}

// Retorna informações completas do plano
export async function getPlanInfo(organizationId: string) {
  const [org] = await db
    .select()
    .from(organizations)
    .where(eq(organizations.id, organizationId))
    .limit(1);

  if (!org) {
    throw new Error("Organization not found");
  }

  const planType = (org.planType as PlanType) || "starter";
  const limits = PLAN_LIMITS[planType];
  const planStatus = await checkPlanStatus(organizationId);

  // Obter contagens atuais
  const [usersCount] = await db
    .select({ count: count() })
    .from(users)
    .where(eq(users.organizationId, organizationId));

  const [customersCount] = await db
    .select({ count: count() })
    .from(customers)
    .where(eq(customers.organizationId, organizationId));

  const now = new Date();
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

  const [transactionsCount] = await db
    .select({ count: count() })
    .from(transactions)
    .where(
      and(
        eq(transactions.organizationId, organizationId),
        sql`${transactions.date} >= ${firstDay}`,
        sql`${transactions.date} <= ${lastDay}`
      )
    );

  return {
    planType,
    ...planStatus,
    limits: {
      users: {
        max: limits.maxUsers,
        current: usersCount?.count || 0,
        available: limits.maxUsers === -1 ? true : (usersCount?.count || 0) < limits.maxUsers,
      },
      customers: {
        max: limits.maxCustomers,
        current: customersCount?.count || 0,
        available: limits.maxCustomers === -1 ? true : (customersCount?.count || 0) < limits.maxCustomers,
      },
      transactions: {
        max: limits.maxTransactionsPerMonth,
        current: transactionsCount?.count || 0,
        available: limits.maxTransactionsPerMonth === -1 ? true : (transactionsCount?.count || 0) < limits.maxTransactionsPerMonth,
      },
    },
    features: limits.features,
  };
}
