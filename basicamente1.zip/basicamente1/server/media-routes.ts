import { Router } from "express";
import { db } from "./db";
import { mediaLibrary, contentVersions, insertMediaLibrarySchema } from "@shared/schema";
import { eq, desc, and, ilike, or } from "drizzle-orm";
import { requireAdmin, requireOwner, logAudit } from "./rbac";
import { upload } from "./upload";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

const router = Router();

router.get("/media", requireAdmin, async (req, res) => {
  try {
    const { mediaType, search, limit = "50", offset = "0" } = req.query;
    
    const conditions = [eq(mediaLibrary.organizationId, req.user!.organizationId!)];
    
    if (mediaType) {
      conditions.push(eq(mediaLibrary.mediaType, mediaType as string));
    }
    
    if (search) {
      const searchTerm = `%${search}%`;
      conditions.push(
        or(
          ilike(mediaLibrary.title, searchTerm),
          ilike(mediaLibrary.description, searchTerm),
          ilike(mediaLibrary.fileName, searchTerm)
        )!
      );
    }
    
    const media = await db
      .select()
      .from(mediaLibrary)
      .where(and(...conditions))
      .orderBy(desc(mediaLibrary.createdAt))
      .limit(parseInt(limit as string))
      .offset(parseInt(offset as string));

    res.json(media);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

router.get("/media/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const media = await db.query.mediaLibrary.findFirst({
      where: and(
        eq(mediaLibrary.id, id),
        eq(mediaLibrary.organizationId, req.user!.organizationId!)
      ),
    });

    if (!media) {
      return res.status(404).json({ message: "Mídia não encontrada" });
    }

    res.json(media);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

router.post("/media/upload", requireAdmin, upload.array("files", 10), async (req, res) => {
  try {
    if (!req.files || !Array.isArray(req.files)) {
      return res.status(400).json({ message: "Nenhum arquivo enviado" });
    }

    const uploadedMedia = [];

    for (const file of req.files) {
      const mediaType = file.mimetype.startsWith("image/") 
        ? "image" 
        : file.mimetype.startsWith("video/")
        ? "video"
        : "document";

      const mediaData = {
        organizationId: req.user!.organizationId!,
        title: req.body.title || file.originalname,
        description: req.body.description || null,
        fileName: file.filename,
        fileSize: file.size,
        mimeType: file.mimetype,
        mediaType,
        url: `/uploads/${file.filename}`,
        thumbnailUrl: null,
        uploadedBy: req.user!.id,
        isPublic: req.body.isPublic !== "false",
        tags: req.body.tags ? JSON.parse(req.body.tags) : null,
      };

      const validatedData = insertMediaLibrarySchema.parse(mediaData);

      const [newMedia] = await db
        .insert(mediaLibrary)
        .values(validatedData)
        .returning();

      await logAudit({
        db,
        userId: req.user!.id,
        action: "upload_media",
        entityType: "media",
        entityId: newMedia.id,
        newValue: newMedia,
        ipAddress: req.ip,
        userAgent: req.get("user-agent"),
      });

      uploadedMedia.push(newMedia);
    }

    res.status(201).json(uploadedMedia);
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: fromZodError(error).message });
    }
    res.status(500).json({ message: error.message });
  }
});

router.put("/media/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const existingMedia = await db.query.mediaLibrary.findFirst({
      where: and(
        eq(mediaLibrary.id, id),
        eq(mediaLibrary.organizationId, req.user!.organizationId!)
      ),
    });

    if (!existingMedia) {
      return res.status(404).json({ message: "Mídia não encontrada" });
    }

    const updateData = {
      title: req.body.title,
      description: req.body.description,
      altText: req.body.altText,
      isPublic: req.body.isPublic,
      tags: req.body.tags,
      updatedAt: new Date(),
    };

    const [updatedMedia] = await db
      .update(mediaLibrary)
      .set(updateData)
      .where(and(
        eq(mediaLibrary.id, id),
        eq(mediaLibrary.organizationId, req.user!.organizationId!)
      ))
      .returning();

    await logAudit({
      db,
      userId: req.user!.id,
      action: "update_media",
      entityType: "media",
      entityId: id,
      oldValue: existingMedia,
      newValue: updatedMedia,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(updatedMedia);
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: fromZodError(error).message });
    }
    res.status(500).json({ message: error.message });
  }
});

router.delete("/media/:id", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const existingMedia = await db.query.mediaLibrary.findFirst({
      where: and(
        eq(mediaLibrary.id, id),
        eq(mediaLibrary.organizationId, req.user!.organizationId!)
      ),
    });

    if (!existingMedia) {
      return res.status(404).json({ message: "Mídia não encontrada" });
    }

    await db
      .delete(mediaLibrary)
      .where(and(
        eq(mediaLibrary.id, id),
        eq(mediaLibrary.organizationId, req.user!.organizationId!)
      ));

    await logAudit({
      db,
      userId: req.user!.id,
      action: "delete_media",
      entityType: "media",
      entityId: id,
      oldValue: existingMedia,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Mídia deletada com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

router.post("/content/:entityType/:entityId/version", requireAdmin, async (req, res) => {
  try {
    const { entityType, entityId } = req.params;
    const { content, changeDescription } = req.body;

    const existingVersions = await db
      .select()
      .from(contentVersions)
      .where(
        and(
          eq(contentVersions.organizationId, req.user!.organizationId!),
          eq(contentVersions.entityType, entityType),
          eq(contentVersions.entityId, entityId)
        )
      )
      .orderBy(desc(contentVersions.versionNumber))
      .limit(1);

    const nextVersion = existingVersions.length > 0 
      ? existingVersions[0].versionNumber + 1 
      : 1;

    const [newVersion] = await db
      .insert(contentVersions)
      .values({
        organizationId: req.user!.organizationId!,
        entityType,
        entityId,
        versionNumber: nextVersion,
        content: JSON.stringify(content),
        changeDescription: changeDescription || null,
        createdBy: req.user!.id,
        isPublished: false,
      })
      .returning();

    await logAudit({
      db,
      userId: req.user!.id,
      action: "create_version",
      entityType: "content_version",
      entityId: newVersion.id,
      newValue: newVersion,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(201).json(newVersion);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

router.get("/content/:entityType/:entityId/versions", requireAdmin, async (req, res) => {
  try {
    const { entityType, entityId } = req.params;

    const versions = await db
      .select()
      .from(contentVersions)
      .where(
        and(
          eq(contentVersions.organizationId, req.user!.organizationId!),
          eq(contentVersions.entityType, entityType),
          eq(contentVersions.entityId, entityId)
        )
      )
      .orderBy(desc(contentVersions.versionNumber));

    res.json(versions);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

router.post("/content/:entityType/:entityId/rollback/:versionId", requireOwner, async (req, res) => {
  try {
    const { entityType, entityId, versionId } = req.params;

    const version = await db.query.contentVersions.findFirst({
      where: and(
        eq(contentVersions.id, versionId),
        eq(contentVersions.organizationId, req.user!.organizationId!)
      ),
    });

    if (!version) {
      return res.status(404).json({ message: "Versão não encontrada" });
    }

    if (version.entityType !== entityType || version.entityId !== entityId) {
      return res.status(400).json({ message: "Versão não corresponde à entidade" });
    }

    await db
      .update(contentVersions)
      .set({ isPublished: true })
      .where(and(
        eq(contentVersions.id, versionId),
        eq(contentVersions.organizationId, req.user!.organizationId!)
      ));

    await db
      .update(contentVersions)
      .set({ isPublished: false })
      .where(
        and(
          eq(contentVersions.organizationId, req.user!.organizationId!),
          eq(contentVersions.entityType, entityType),
          eq(contentVersions.entityId, entityId),
          eq(contentVersions.isPublished, true)
        )
      );

    await logAudit({
      db,
      userId: req.user!.id,
      action: "rollback_content",
      entityType,
      entityId,
      newValue: { versionId, versionNumber: version.versionNumber },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Rollback realizado com sucesso", version });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
