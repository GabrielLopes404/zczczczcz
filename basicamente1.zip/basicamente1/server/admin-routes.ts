import { Router } from "express";
import { db } from "./db";
import { users, supportTickets, ticketMessages, organizations, subscriptions, paymentHistory } from "@shared/schema";
import { eq, and, or, desc, sql, count, ilike } from "drizzle-orm";
import { requireAdmin, requireOwner, canManageUser, logAudit } from "./rbac";
import bcrypt from "bcryptjs";

const router = Router();

// ========================
// USER MANAGEMENT (ADMIN & OWNER)
// ========================

// Get all users (paginated) - ADMIN and OWNER
router.get("/users", requireAdmin, async (req, res) => {
  try {
    const { page = "1", limit = "50", search = "" } = req.query;
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    // Build query conditions
    // CRITICAL FIX: Organization filter must be ANDed with the entire search expression to prevent cross-tenant leaks
    const orgFilter = eq(users.organizationId, req.user!.organizationId!);
    
    let whereCondition;
    if (search) {
      const searchTerm = `%${search}%`;
      // Use or() helper to properly group search conditions, then AND with org filter
      whereCondition = and(
        orgFilter,
        or(
          ilike(users.name, searchTerm),
          ilike(users.email, searchTerm),
          ilike(users.username, searchTerm)
        )
      );
    } else {
      whereCondition = orgFilter;
    }

    // Build query with properly scoped conditions
    const allUsers = await db
      .select()
      .from(users)
      .where(whereCondition)
      .orderBy(desc(users.createdAt))
      .limit(limitNum)
      .offset(offset);

    // Remove sensitive data
    const sanitizedUsers = allUsers.map(({ password, twoFactorSecret, resetToken, ...user }) => user);

    // Get total count with same properly scoped conditions
    const totalResult = await db
      .select({ count: count() })
      .from(users)
      .where(whereCondition);

    res.json({
      users: sanitizedUsers,
      total: totalResult[0]?.count || 0,
      page: pageNum,
      limit: limitNum,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get single user details - ADMIN and OWNER
router.get("/users/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const user = await db.query.users.findFirst({
      where: eq(users.id, id),
    });

    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    // CRITICAL: Both ADMIN and OWNER can only view users from their organization (tenant isolation)
    if (user.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    // Remove sensitive data
    const { password, twoFactorSecret, resetToken, ...sanitizedUser } = user;

    res.json(sanitizedUser);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Promote user to ADMIN - OWNER only
router.post("/users/:id/promote", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const user = await db.query.users.findFirst({
      where: eq(users.id, id),
    });

    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    // CRITICAL: Verify organization ownership before promoting (tenant isolation)
    if (user.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado: Você só pode gerenciar usuários da sua organização" });
    }

    if (user.role === "OWNER") {
      return res.status(400).json({ message: "Não é possível promover um OWNER" });
    }

    if (user.role === "ADMIN") {
      return res.status(400).json({ message: "Usuário já é ADMIN" });
    }

    const oldValue = { role: user.role };
    const newValue = { role: "ADMIN" };

    await db.update(users).set({ role: "ADMIN" }).where(eq(users.id, id));

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      organizationId: user.organizationId,
      action: "promote_user",
      entityType: "user",
      entityId: id,
      oldValue,
      newValue,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Usuário promovido para ADMIN com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Demote user to CUSTOMER - OWNER only
router.post("/users/:id/demote", requireOwner, async (req, res) => {
  try {
    const { id } = req.params;

    const user = await db.query.users.findFirst({
      where: eq(users.id, id),
    });

    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    // CRITICAL: Verify organization ownership before demoting (tenant isolation)
    if (user.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado: Você só pode gerenciar usuários da sua organização" });
    }

    if (user.role === "OWNER") {
      return res.status(400).json({ message: "Não é possível rebaixar um OWNER" });
    }

    if (user.role === "CUSTOMER") {
      return res.status(400).json({ message: "Usuário já é CUSTOMER" });
    }

    const oldValue = { role: user.role };
    const newValue = { role: "CUSTOMER" };

    await db.update(users).set({ role: "CUSTOMER" }).where(eq(users.id, id));

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      organizationId: user.organizationId,
      action: "demote_user",
      entityType: "user",
      entityId: id,
      oldValue,
      newValue,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Usuário rebaixado para CUSTOMER com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Delete/Suspend user - ADMIN and OWNER
router.delete("/users/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const user = await db.query.users.findFirst({
      where: eq(users.id, id),
    });

    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    // Check permissions
    const currentUserRole = req.user!.role;
    if (currentUserRole === "CUSTOMER") {
      return res.status(403).json({ message: "Você não pode gerenciar usuários" });
    }
    
    // ADMIN can only manage CUSTOMER
    if (currentUserRole === "ADMIN" && user.role !== "CUSTOMER") {
      return res.status(403).json({ message: "ADMIN só pode gerenciar usuários CUSTOMER" });
    }

    if (user.role === "OWNER") {
      return res.status(400).json({ message: "Não é possível deletar um OWNER" });
    }

    // CRITICAL: Both ADMIN and OWNER can only delete users from their organization (tenant isolation)
    if (user.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    await db.delete(users).where(eq(users.id, id));

    // Log audit
    await logAudit({
      db,
      userId: req.user!.id,
      organizationId: user.organizationId,
      action: "delete_user",
      entityType: "user",
      entityId: id,
      oldValue: { email: user.email, role: user.role },
      newValue: null,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({ message: "Usuário deletado com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// ========================
// SUPPORT TICKETS (ADMIN & OWNER)
// ========================

// Get all support tickets - ADMIN and OWNER
router.get("/tickets", requireAdmin, async (req, res) => {
  try {
    const { status, page = "1", limit = "50" } = req.query;
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const offset = (pageNum - 1) * limitNum;

    // Build query conditions
    const ticketConditions: any[] = [];
    
    // CRITICAL: Both ADMIN and OWNER must only see tickets from their organization (tenant isolation)
    ticketConditions.push(eq(supportTickets.organizationId, req.user!.organizationId!));

    // Filter by status if provided
    if (status && typeof status === "string") {
      ticketConditions.push(eq(supportTickets.status, status));
    }

    // Build query with combined conditions
    let query = db
      .select()
      .from(supportTickets)
      .orderBy(desc(supportTickets.createdAt))
      .limit(limitNum)
      .offset(offset);

    if (ticketConditions.length > 0) {
      query = query.where(and(...ticketConditions)) as any;
    }

    const tickets = await query;

    // Get total count with same conditions
    let countQuery = db
      .select({ count: count() })
      .from(supportTickets);

    if (ticketConditions.length > 0) {
      countQuery = countQuery.where(and(...ticketConditions)) as any;
    }

    const totalResult = await countQuery;

    res.json({
      tickets,
      total: totalResult[0]?.count || 0,
      page: pageNum,
      limit: limitNum,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get ticket with messages - ADMIN and OWNER
router.get("/tickets/:id", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const ticket = await db.query.supportTickets.findFirst({
      where: eq(supportTickets.id, id),
    });

    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }

    // CRITICAL: Both ADMIN and OWNER can only view tickets from their organization (tenant isolation)
    if (ticket.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    // Get messages
    const messages = await db
      .select()
      .from(ticketMessages)
      .where(eq(ticketMessages.ticketId, id))
      .orderBy(ticketMessages.createdAt);

    res.json({ ticket, messages });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Assign ticket to admin - ADMIN and OWNER
router.post("/tickets/:id/assign", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { assignedTo } = req.body;

    const ticket = await db.query.supportTickets.findFirst({
      where: eq(supportTickets.id, id),
    });

    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }

    // CRITICAL: Both ADMIN and OWNER can only assign tickets from their organization (tenant isolation)
    if (ticket.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    await db
      .update(supportTickets)
      .set({ assignedTo, status: "in_progress" })
      .where(eq(supportTickets.id, id));

    res.json({ message: "Ticket atribuído com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Resolve ticket - ADMIN and OWNER
router.post("/tickets/:id/resolve", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    const ticket = await db.query.supportTickets.findFirst({
      where: eq(supportTickets.id, id),
    });

    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }

    // CRITICAL: Both ADMIN and OWNER can only resolve tickets from their organization (tenant isolation)
    if (ticket.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    await db
      .update(supportTickets)
      .set({ status: "resolved", resolvedAt: new Date() })
      .where(eq(supportTickets.id, id));

    res.json({ message: "Ticket resolvido com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Reply to ticket - ADMIN and OWNER
router.post("/tickets/:id/reply", requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { message, isInternal = false } = req.body;

    const ticket = await db.query.supportTickets.findFirst({
      where: eq(supportTickets.id, id),
    });

    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }

    // CRITICAL: Both ADMIN and OWNER can only reply to tickets from their organization (tenant isolation)
    if (ticket.organizationId !== req.user!.organizationId) {
      return res.status(403).json({ message: "Acesso negado" });
    }

    await db.insert(ticketMessages).values({
      ticketId: id,
      userId: req.user!.id,
      message,
      isInternal,
    });

    res.json({ message: "Resposta enviada com sucesso" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// ========================
// GENERAL REPORTS (ADMIN & OWNER)
// ========================

// Get platform statistics - ADMIN and OWNER
router.get("/statistics", requireAdmin, async (req, res) => {
  try {
    // CRITICAL: Both ADMIN and OWNER can only see statistics from their organization (tenant isolation)
    const [totalUsers, openTickets] = await Promise.all([
      db.select({ count: count() }).from(users).where(eq(users.organizationId, req.user!.organizationId!)),
      db.select({ count: count() }).from(supportTickets).where(
        and(
          eq(supportTickets.organizationId, req.user!.organizationId!),
          eq(supportTickets.status, "open")
        )
      ),
    ]);

    const stats = {
      totalUsers: totalUsers[0]?.count || 0,
      openTickets: openTickets[0]?.count || 0,
    };

    res.json(stats);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
