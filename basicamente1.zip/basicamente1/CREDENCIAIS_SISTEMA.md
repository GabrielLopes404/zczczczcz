# Credenciais do Sistema LUCREI

## Credenciais de Acesso

### Owner (Proprietário)
- **Email**: demo@lucrei.com
- **Senha**: demo123
- **Papel**: OWNER
- **Organização**: Demo Company

### Admin (Administrador)
- **Email**: admin@lucrei.com
- **Senha**: demo123
- **Papel**: ADMIN
- **Organização**: Demo Company

## Níveis de Acesso

### 1. OWNER (Proprietário)
O OWNER tem controle total sobre a organização e é o único com as seguintes permissões especiais:

**Permissões Exclusivas:**
- Promover usuários para ADMIN (`POST /api/admin/users/:id/promote`)
- Rebaixar ADMINs para CUSTOMER (`POST /api/admin/users/:id/demote`)
- Gerenciar planos de assinatura (CRUD completo em `/api/owner/plans`)
- Configurar branding da organização (`/api/owner/branding`)
- Acessar logs de auditoria (`/api/owner/audit-logs`)
- Visualizar métricas avançadas (MRR, churn, LTV) (`/api/owner/metrics`)
- Gerenciar todas as assinaturas (`/api/owner/subscriptions`)
- Acessar histórico de pagamentos (`/api/owner/payments`)

**Acesso Completo a:**
- Todas as funcionalidades de ADMIN
- Todas as funcionalidades de CUSTOMER
- Dashboard do Owner (`/app/owner-dashboard`)
- Gerenciamento de planos (`/app/owner/plans`)
- Personalização de marca (`/app/owner/branding`)
- Páginas de conteúdo CMS (`/app/owner/content`)

### 2. ADMIN (Administrador)
O ADMIN tem permissões administrativas amplas, mas não pode alterar configurações críticas da organização.

**Permissões Principais:**
- Gerenciar usuários da organização (visualizar, convidar, remover)
- Gerenciar tickets de suporte (atribuir, resolver, responder)
- Visualizar estatísticas da plataforma
- Acessar dashboard administrativo (`/app/admin-dashboard`)
- Gerenciar usuários (`/app/admin/users`)
- Gerenciar tickets (`/app/admin/tickets`)

**Endpoints Administrativos:**
- `GET /api/admin/users` - Listar usuários da organização
- `GET /api/admin/users/:id` - Detalhes do usuário
- `DELETE /api/admin/users/:id` - Deletar usuário
- `GET /api/admin/tickets` - Listar tickets de suporte
- `GET /api/admin/tickets/:id` - Detalhes do ticket
- `POST /api/admin/tickets/:id/assign` - Atribuir ticket
- `POST /api/admin/tickets/:id/resolve` - Resolver ticket
- `POST /api/admin/tickets/:id/reply` - Responder ticket
- `GET /api/admin/statistics` - Estatísticas da plataforma

**Acesso Completo a:**
- Todas as funcionalidades de CUSTOMER
- Gerenciamento avançado de dados
- Relatórios e análises

### 3. CUSTOMER (Cliente/Usuário)
O CUSTOMER tem permissões limitadas, focadas em operações do dia a dia.

**Permissões:**
- Gerenciar transações próprias
- Criar e editar faturas
- Visualizar relatórios pessoais
- Gerenciar clientes
- Importar e exportar dados
- Gerenciar categorias, centros de custo, tags
- Gerenciar documentos
- Configurar perfil e preferências

**Páginas Acessíveis:**
- `/app/dashboard` - Dashboard principal
- `/app/transactions` - Transações
- `/app/customers` - Clientes
- `/app/invoices` - Faturas
- `/app/reports` - Relatórios
- `/app/imports` - Importações
- `/app/reconciliations` - Conciliações
- `/app/profile` - Perfil
- `/app/settings` - Configurações
- `/app/subscription` - Minha Assinatura

## Sistema de Assinaturas

### Planos Disponíveis

#### STARTER - R$ 47,00/mês
- Até 100 clientes
- Faturas ilimitadas
- Relatórios básicos
- 2 usuários
- Suporte por email
- 7 dias de teste grátis

#### BUSINESS - R$ 147,00/mês (Mais Popular)
- Clientes ilimitados
- Faturas ilimitadas
- Relatórios avançados (DRE, Fluxo de Caixa)
- Até 10 usuários
- API de integração
- Suporte prioritário
- Automação de cobranças
- 7 dias de teste grátis

#### ENTERPRISE - Personalizado
- Tudo do BUSINESS
- Usuários ilimitados
- SLA garantido
- Gerente de conta dedicado
- Onboarding personalizado
- Customizações sob medida

### Período de Trial
- **Duração**: 7 dias gratuitos
- **Início**: Automaticamente na criação da conta
- **Banner de Notificação**: Exibido no topo do sistema mostrando dias restantes
- **Ações Disponíveis**:
  - Assinar (redireciona para página de assinatura)
  - Falar com especialista (abre WhatsApp)
  - Ativar (redireciona para página de assinatura)

### Fluxo de Assinatura
1. Usuário seleciona plano na página `/app/subscription`
2. Sistema cria checkout session no Stripe com trial de 7 dias
3. Usuário é redirecionado para página de pagamento do Stripe
4. Após conclusão, webhook atualiza status da assinatura
5. Acesso completo é liberado

### Gerenciamento de Assinatura
- **Portal do Cliente**: Botão "Gerenciar Assinatura" redireciona para portal Stripe
- **Funcionalidades do Portal**:
  - Atualizar método de pagamento
  - Alterar plano
  - Cancelar assinatura
  - Ver histórico de faturas
  - Baixar recibos

## Segurança

### Autenticação
- Session-based authentication com Passport.js
- Senhas hasheadas com bcrypt (12 rounds)
- Sessions armazenadas no PostgreSQL
- CSRF protection ativo em todas as rotas de mutação

### Rate Limiting
- 100 requisições por minuto (geral)
- 5 tentativas de login a cada 15 minutos

### Isolamento de Dados (Tenant Isolation)
- Todas as queries filtradas por `organizationId`
- Verificação de organização antes de modificar dados
- Logs de auditoria para ações administrativas

### Variáveis de Ambiente Necessárias

```bash
# Database
DATABASE_URL=postgresql://...

# Session
SESSION_SECRET=sua-string-super-secreta

# Stripe
STRIPE_SECRET_KEY=sk_test_... ou sk_live_...
VITE_STRIPE_PUBLIC_KEY=pk_test_... ou pk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Sentry (Opcional)
SENTRY_DSN=https://...
```

## Endpoints Principais da API

### Autenticação
- `POST /api/auth/register` - Registrar novo usuário
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Dados do usuário atual

### Assinaturas (Stripe)
- `GET /api/subscription` - Obter assinatura atual
- `POST /api/stripe/create-checkout-session` - Criar checkout
- `POST /api/stripe/create-portal-session` - Abrir portal de gerenciamento
- `POST /api/webhooks/stripe` - Webhook do Stripe

### Admin (ADMIN + OWNER)
- Gerenciamento de usuários
- Gerenciamento de tickets de suporte
- Estatísticas da plataforma

### Owner (OWNER apenas)
- Gerenciamento de planos
- Configuração de branding
- Logs de auditoria
- Métricas financeiras (MRR, churn, LTV)

## Como Usar

### Para Testar como OWNER:
1. Acesse: http://localhost:5000/login
2. Email: demo@lucrei.com
3. Senha: demo123
4. Você terá acesso a todas as funcionalidades, incluindo:
   - `/app/owner-dashboard` - Dashboard do proprietário
   - `/app/owner/plans` - Gerenciar planos de assinatura
   - `/app/owner/branding` - Personalizar marca
   - Promoção/rebaixamento de usuários

### Para Testar como ADMIN:
1. Acesse: http://localhost:5000/login
2. Email: admin@lucrei.com
3. Senha: demo123
4. Você terá acesso a funcionalidades administrativas:
   - `/app/admin-dashboard` - Dashboard administrativo
   - `/app/admin/users` - Gerenciar usuários
   - `/app/admin/tickets` - Gerenciar tickets
   - Sem acesso a configurações de planos e branding

## Notas Importantes

1. **Trial Automático**: Todo novo usuário recebe 7 dias de trial automaticamente
2. **Banner de Notificação**: Exibido para usuários em trial mostrando dias restantes
3. **Bloqueio Pós-Trial**: Após expiração do trial, acesso é bloqueado até assinatura ativa
4. **Renovação Automática**: Assinaturas renovam automaticamente via Stripe
5. **Webhooks**: Sistema processa eventos do Stripe para atualizar status de assinatura
6. **Logs de Auditoria**: Todas as ações administrativas são registradas

## Suporte

Para questões sobre o sistema, consulte:
- `RUNBOOK.md` - Guia operacional completo
- `DEPLOYMENT.md` - Guia de deployment
- `docs/rbac-matrix.md` - Matriz de permissões RBAC
- `docs/SISTEMA_ACESSO_ADMINISTRATIVO.md` - Detalhes do sistema administrativo
