import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Shield, Lock, Eye, Server, FileCheck, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

export default function SegurancaPage() {
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: Lock,
      title: "Criptografia de Ponta a Ponta",
      description: "Todos os dados são criptografados em trânsito (TLS 1.3) e em repouso (AES-256)."
    },
    {
      icon: Eye,
      title: "Auditoria Completa",
      description: "Registro detalhado de todas as ações realizadas na plataforma para rastreabilidade total."
    },
    {
      icon: Server,
      title: "Infraestrutura Segura",
      description: "Hospedagem em servidores de nível empresarial com backup automático e redundância."
    },
    {
      icon: FileCheck,
      title: "Conformidade LGPD",
      description: "100% em conformidade com a Lei Geral de Proteção de Dados Pessoais."
    },
    {
      icon: Shield,
      title: "Autenticação Segura",
      description: "Senhas com hash bcrypt, proteção contra força bruta e suporte a 2FA."
    },
    {
      icon: AlertTriangle,
      title: "Monitoramento 24/7",
      description: "Detecção e resposta a ameaças em tempo real com alertas automáticos."
    }
  ];

  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-4 md:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-gradient-to-r from-primary to-primary/80 flex items-center justify-center">
              <Shield className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl md:text-4xl sm:text-xl md:text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
            Segurança da Informação
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Seus dados financeiros protegidos com os mais altos padrões de segurança
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6 mb-12">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-primary to-primary flex items-center justify-center flex-shrink-0">
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground text-sm">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <Card className="mb-8">
          <CardContent className="p-4 md:p-8">
            <h2 className="text-2xl font-bold mb-4">Nossa Abordagem de Segurança</h2>
            <div className="space-y-4 text-muted-foreground">
              <p>
                A segurança não é apenas uma funcionalidade no LUCREI - é a base de tudo que fazemos. 
                Implementamos múltiplas camadas de proteção para garantir que seus dados financeiros estejam 
                sempre seguros.
              </p>
              <p>
                Nossa equipe de segurança trabalha 24/7 monitorando ameaças, aplicando patches de segurança 
                e mantendo nossa infraestrutura atualizada com as melhores práticas do setor.
              </p>
              <p>
                Realizamos testes de penetração regulares e auditorias de segurança por empresas terceirizadas 
                para garantir que nossos sistemas estejam sempre protegidos contra as ameaças mais recentes.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-primary/10 to-primary/10 border-primary/20">
          <CardContent className="p-4 md:p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Reportar um Problema de Segurança</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Se você descobriu uma vulnerabilidade de segurança, entre em contato imediatamente 
              com nossa equipe de segurança: security@lucrei.app
            </p>
            <Button 
              variant="outline"
              onClick={() => setLocation("/contato")}
            >
              Reportar Vulnerabilidade
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
