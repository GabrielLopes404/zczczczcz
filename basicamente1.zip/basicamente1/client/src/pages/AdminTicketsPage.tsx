import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, MessageSquare, CheckCircle2, Clock, AlertCircle, Search, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Ticket {
  id: string;
  subject: string;
  description: string;
  status: string;
  priority: string;
  category: string;
  userId: string;
  organizationId: string;
  assignedTo: string | null;
  createdAt: string;
  updatedAt: string;
}

interface TicketMessage {
  id: string;
  ticketId: string;
  userId: string;
  message: string;
  isInternal: boolean;
  createdAt: string;
}

export default function AdminTicketsPage() {
  const [csrfToken, setCsrfToken] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [replyMessage, setReplyMessage] = useState("");
  const [isInternal, setIsInternal] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  const { data: ticketsData, isLoading } = useQuery({
    queryKey: ["/api/admin/tickets", statusFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (statusFilter !== "all") {
        params.append("status", statusFilter);
      }
      const res = await fetch(`/api/admin/tickets?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch tickets");
      return res.json();
    },
  });

  const { data: ticketDetails } = useQuery({
    queryKey: ["/api/admin/tickets", selectedTicket?.id],
    queryFn: async () => {
      if (!selectedTicket) return null;
      const res = await fetch(`/api/admin/tickets/${selectedTicket.id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch ticket details");
      return res.json();
    },
    enabled: !!selectedTicket,
  });

  const replyMutation = useMutation({
    mutationFn: async ({ ticketId, message, isInternal }: { ticketId: string; message: string; isInternal: boolean }) => {
      const res = await fetch(`/api/admin/tickets/${ticketId}/reply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify({ message, isInternal }),
      });
      if (!res.ok) throw new Error("Failed to send reply");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tickets"] });
      setReplyMessage("");
      toast({
        title: "Resposta enviada",
        description: "Sua resposta foi enviada com sucesso",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao enviar resposta",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resolveMutation = useMutation({
    mutationFn: async (ticketId: string) => {
      const res = await fetch(`/api/admin/tickets/${ticketId}/resolve`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to resolve ticket");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tickets"] });
      setSelectedTicket(null);
      toast({
        title: "Ticket resolvido",
        description: "O ticket foi marcado como resolvido",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao resolver ticket",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = (status: string) => {
    const styles = {
      open: "bg-blue-500",
      in_progress: "bg-yellow-500",
      resolved: "bg-green-500",
      closed: "bg-gray-500",
    };
    return <Badge className={styles[status as keyof typeof styles] || "bg-gray-500"}>{status}</Badge>;
  };

  const getPriorityBadge = (priority: string) => {
    const styles = {
      low: "bg-gray-500",
      medium: "bg-blue-500",
      high: "bg-orange-500",
      urgent: "bg-red-500",
    };
    return <Badge className={styles[priority as keyof typeof styles] || "bg-gray-500"}>{priority}</Badge>;
  };

  const filteredTickets = ticketsData?.tickets?.filter((ticket: Ticket) => {
    if (!searchTerm) return true;
    return (
      ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }) || [];

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="ml-2 text-muted-foreground">Carregando tickets...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-xl md:text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Gestão de Tickets
          </h1>
          <p className="text-muted-foreground mt-1">
            Gerencie todos os tickets de suporte dos clientes
          </p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <div>
                <CardTitle>Tickets de Suporte</CardTitle>
                <CardDescription>
                  {ticketsData?.total || 0} tickets encontrados
                </CardDescription>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-64">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar tickets..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="open">Aberto</SelectItem>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="resolved">Resolvido</SelectItem>
                    <SelectItem value="closed">Fechado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Assunto</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Prioridade</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTickets.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      Nenhum ticket encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTickets.map((ticket: Ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell className="font-medium">{ticket.subject}</TableCell>
                      <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                      <TableCell>{getPriorityBadge(ticket.priority)}</TableCell>
                      <TableCell>{ticket.category || "N/A"}</TableCell>
                      <TableCell>
                        {format(new Date(ticket.createdAt), "dd/MM/yyyy", { locale: ptBR })}
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedTicket(ticket)}
                            >
                              <MessageSquare className="h-4 w-4 mr-2" />
                              Ver Detalhes
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>{ticket.subject}</DialogTitle>
                              <DialogDescription>
                                Ticket #{ticket.id.slice(0, 8)} - {format(new Date(ticket.createdAt), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="flex gap-2">
                                {getStatusBadge(ticket.status)}
                                {getPriorityBadge(ticket.priority)}
                                {ticket.category && (
                                  <Badge variant="outline">{ticket.category}</Badge>
                                )}
                              </div>
                              <div>
                                <h4 className="font-semibold mb-2">Descrição:</h4>
                                <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                                  {ticket.description}
                                </p>
                              </div>
                              {ticketDetails?.messages && ticketDetails.messages.length > 0 && (
                                <div>
                                  <h4 className="font-semibold mb-2">Mensagens:</h4>
                                  <div className="space-y-2 max-h-60 overflow-y-auto">
                                    {ticketDetails.messages.map((msg: TicketMessage) => (
                                      <div
                                        key={msg.id}
                                        className={`p-3 rounded-lg ${
                                          msg.isInternal
                                            ? "bg-yellow-50 border border-yellow-200"
                                            : "bg-muted"
                                        }`}
                                      >
                                        <div className="flex items-center gap-2 mb-1">
                                          <span className="text-xs font-medium">
                                            {format(new Date(msg.createdAt), "dd/MM HH:mm", { locale: ptBR })}
                                          </span>
                                          {msg.isInternal && (
                                            <Badge variant="outline" className="text-xs">
                                              Interno
                                            </Badge>
                                          )}
                                        </div>
                                        <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                              <div className="space-y-2">
                                <label className="text-sm font-medium">Responder:</label>
                                <Textarea
                                  placeholder="Digite sua resposta..."
                                  value={replyMessage}
                                  onChange={(e) => setReplyMessage(e.target.value)}
                                  rows={4}
                                />
                                <div className="flex items-center gap-2">
                                  <input
                                    type="checkbox"
                                    id="internal"
                                    checked={isInternal}
                                    onChange={(e) => setIsInternal(e.target.checked)}
                                    className="rounded"
                                  />
                                  <label htmlFor="internal" className="text-sm">
                                    Nota interna (não visível ao cliente)
                                  </label>
                                </div>
                              </div>
                            </div>
                            <DialogFooter>
                              <Button
                                variant="outline"
                                onClick={() => {
                                  setSelectedTicket(null);
                                  setReplyMessage("");
                                }}
                              >
                                Cancelar
                              </Button>
                              {ticket.status !== "resolved" && ticket.status !== "closed" && (
                                <Button
                                  variant="default"
                                  onClick={() => resolveMutation.mutate(ticket.id)}
                                  disabled={resolveMutation.isPending}
                                >
                                  {resolveMutation.isPending ? (
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                  ) : (
                                    <CheckCircle2 className="h-4 w-4 mr-2" />
                                  )}
                                  Marcar como Resolvido
                                </Button>
                              )}
                              <Button
                                onClick={() =>
                                  replyMutation.mutate({
                                    ticketId: ticket.id,
                                    message: replyMessage,
                                    isInternal,
                                  })
                                }
                                disabled={!replyMessage.trim() || replyMutation.isPending}
                              >
                                {replyMutation.isPending ? (
                                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                ) : (
                                  <MessageSquare className="h-4 w-4 mr-2" />
                                )}
                                Enviar Resposta
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
