import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { PageContainer } from "@/components/PageContainer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, DollarSign, BarChart3, FileText, Crown, TrendingUp, Activity, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function AdminDashboardPage() {
  // Queries
  const { data: usersData } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    queryFn: async () => {
      const res = await fetch("/api/dashboard/metrics", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch dashboard metrics");
      return res.json();
    },
  });

  const { data: transactionsData } = useQuery({
    queryKey: ["/api/transactions"],
    queryFn: async () => {
      const res = await fetch("/api/transactions?limit=10", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return res.json();
    },
  });

  return (
    <PageContainer
      title="Painel Administrativo"
      description="Gerencie usuários e visualize relatórios do sistema"
    >
      <motion.div 
        className="grid gap-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Cards de Métricas */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-blue-500/20 bg-gradient-to-br from-blue-500/10 via-background to-background hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
                <div className="p-2 rounded-lg bg-blue-500/10">
                  <Users className="h-4 w-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                  {usersData?.users?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Ativos: {usersData?.users?.filter((u: any) => u.emailVerified).length || 0}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-green-500/20 bg-gradient-to-br from-green-500/10 via-background to-background hover:shadow-lg hover:shadow-green-500/20 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                <div className="p-2 rounded-lg bg-green-500/10">
                  <DollarSign className="h-4 w-4 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                  R$ {dashboardData?.totalRevenue?.toLocaleString("pt-BR") || "0,00"}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  Este mês: R$ {dashboardData?.monthlyRevenue?.toLocaleString("pt-BR") || "0,00"}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-purple-500/20 bg-gradient-to-br from-purple-500/10 via-background to-background hover:shadow-lg hover:shadow-purple-500/20 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Transações</CardTitle>
                <div className="p-2 rounded-lg bg-purple-500/10">
                  <BarChart3 className="h-4 w-4 text-purple-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  {dashboardData?.totalTransactions || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <Activity className="h-3 w-3" />
                  Este mês: {dashboardData?.monthlyTransactions || 0}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-orange-500/20 bg-gradient-to-br from-orange-500/10 via-background to-background hover:shadow-lg hover:shadow-orange-500/20 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Faturas Pendentes</CardTitle>
                <div className="p-2 rounded-lg bg-orange-500/10">
                  <FileText className="h-4 w-4 text-orange-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold bg-gradient-to-r from-orange-400 to-amber-400 bg-clip-text text-transparent">
                  {dashboardData?.pendingInvoices || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  Total: R$ {dashboardData?.pendingAmount?.toLocaleString("pt-BR") || "0,00"}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList>
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="payments">Pagamentos</TabsTrigger>
            <TabsTrigger value="reports">Relatórios Gerais</TabsTrigger>
          </TabsList>

          {/* Tab de Usuários */}
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Gerenciar Usuários</CardTitle>
                <CardDescription>
                  Visualize e gerencie todos os usuários do sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Função</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Cadastrado em</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usersData?.users?.map((user: any) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name || user.username}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              user.role === "OWNER"
                                ? "default"
                                : user.role === "ADMIN"
                                ? "secondary"
                                : "outline"
                            }
                          >
                            {user.role === "OWNER" && <Crown className="h-3 w-3 mr-1" />}
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={user.emailVerified ? "default" : "outline"}>
                            {user.emailVerified ? "Ativo" : "Pendente"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {format(new Date(user.createdAt), "dd/MM/yyyy")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab de Pagamentos */}
          <TabsContent value="payments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Histórico de Pagamentos</CardTitle>
                <CardDescription>
                  Visualize o histórico de transações (somente leitura)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactionsData?.transactions?.map((transaction: any) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="text-sm">
                          {format(new Date(transaction.date), "dd/MM/yyyy")}
                        </TableCell>
                        <TableCell className="font-medium">{transaction.description}</TableCell>
                        <TableCell>
                          <Badge variant={transaction.type === "income" ? "default" : "destructive"}>
                            {transaction.type === "income" ? "Receita" : "Despesa"}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono">
                          R$ {parseFloat(transaction.amount).toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                          })}
                        </TableCell>
                        <TableCell>
                          <Badge variant={transaction.status === "paid" ? "default" : "outline"}>
                            {transaction.status || "Pendente"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    ℹ️ <strong>Nota:</strong> Como administrador, você pode visualizar o histórico de pagamentos,
                    mas não pode alterar valores ou configurações de preços. Essas ações são exclusivas do
                    proprietário do sistema.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab de Relatórios */}
          <TabsContent value="reports" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios Financeiros Gerais</CardTitle>
                <CardDescription>
                  Visualize métricas e comparativos de clientes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="rounded-lg border p-4">
                      <h3 className="font-semibold mb-2">Resumo Mensal</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Receitas:</span>
                          <span className="font-mono text-green-600">
                            R$ {dashboardData?.monthlyIncome?.toLocaleString("pt-BR") || "0,00"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Despesas:</span>
                          <span className="font-mono text-red-600">
                            R$ {dashboardData?.monthlyExpenses?.toLocaleString("pt-BR") || "0,00"}
                          </span>
                        </div>
                        <div className="flex justify-between border-t pt-2">
                          <span className="font-medium">Lucro:</span>
                          <span className="font-mono font-bold">
                            R$ {((dashboardData?.monthlyIncome || 0) - (dashboardData?.monthlyExpenses || 0)).toLocaleString("pt-BR")}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="font-semibold mb-2">Estatísticas de Clientes</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total de clientes:</span>
                          <span className="font-medium">{dashboardData?.totalCustomers || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Novos este mês:</span>
                          <span className="font-medium">{dashboardData?.newCustomers || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Taxa de retenção:</span>
                          <span className="font-medium">{dashboardData?.retentionRate || 0}%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-4 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      ℹ️ <strong>Limitações do Administrador:</strong> Você pode visualizar todos os relatórios
                      financeiros e comparar dados de clientes, mas não pode acessar os logs do sistema,
                      integrações, webhooks ou alterar configurações da plataforma. Para essas funcionalidades,
                      contate o proprietário do sistema.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </PageContainer>
  );
}
