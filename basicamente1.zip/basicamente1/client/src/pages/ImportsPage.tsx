import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Upload, FileText, Users, Download, AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

interface CSVPreviewData {
  headers: string[];
  rows: string[][];
  totalRows: number;
}

export default function ImportsPage() {
  const { toast } = useToast();
  const [showCSVDialog, setShowCSVDialog] = useState(false);
  const [csvFile, setCSVFile] = useState<File | null>(null);
  const [csvPreview, setCSVPreview] = useState<CSVPreviewData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isExporting, setIsExporting] = useState(false);

  const handleCSVFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Erro",
        description: "Por favor, selecione um arquivo CSV",
        variant: "destructive",
      });
      return;
    }

    setCSVFile(file);
    
    const text = await file.text();
    const lines = text.split('\n').filter(line => line.trim());
    
    if (lines.length < 2) {
      toast({
        title: "Erro",
        description: "Arquivo CSV vazio ou inválido",
        variant: "destructive",
      });
      return;
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const rows = lines.slice(1, 11).map(line => 
      line.split(',').map(cell => cell.trim().replace(/^"|"$/g, ''))
    );

    setCSVPreview({
      headers,
      rows,
      totalRows: lines.length - 1
    });
  };

  const handleImportCSV = async () => {
    if (!csvFile) return;

    setIsProcessing(true);
    setValidationErrors([]);

    const formData = new FormData();
    formData.append('file', csvFile);

    try {
      const csrfResponse = await fetch('/api/csrf-token', { credentials: 'include' });
      const { csrfToken } = await csrfResponse.json();

      const response = await fetch('/api/transactions/import-csv', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'X-CSRF-Token': csrfToken,
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        if (data.errors && Array.isArray(data.errors)) {
          setValidationErrors(data.errors);
        }
        throw new Error(data.message || 'Erro ao importar CSV');
      }

      toast({
        title: "Sucesso!",
        description: `${data.imported} transações importadas com sucesso`,
      });

      setShowCSVDialog(false);
      setCSVFile(null);
      setCSVPreview(null);
    } catch (error: any) {
      toast({
        title: "Erro ao importar",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExportHistory = async () => {
    try {
      setIsExporting(true);
      const csrfRes = await fetch("/api/csrf-token", { credentials: "include" });
      const { csrfToken } = await csrfRes.json();

      const today = new Date().toISOString().split('T')[0];
      const params = new URLSearchParams({
        startDate: new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toISOString().split('T')[0],
        endDate: today,
        format: "xlsx",
      });

      const res = await fetch(`/api/exports/transactions?${params}`, {
        credentials: "include",
        headers: {
          "X-CSRF-Token": csrfToken
        }
      });

      if (!res.ok) throw new Error("Failed to export history");

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `import_history_${today}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({ title: "Histórico exportado com sucesso!" });
    } catch (error) {
      toast({
        title: "Erro ao exportar histórico",
        description: (error as Error).message,
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const importTypes = [
    {
      icon: FileSpreadsheet,
      title: "Importação padrão",
      description: "Importação de dados simples, utilizando o nosso formato",
      badge: null,
    },
    {
      icon: FileText,
      title: "Zero Paper",
      description: "Importação de dados utilizando o Excel do Zero Paper",
      badge: null,
    },
    {
      icon: Users,
      title: "Contatos",
      description: "Importação de contatos, utilizando o Excel",
      badge: null,
    },
    {
      icon: FileSpreadsheet,
      title: "OFX",
      description: "Importação de dados utilizando o formato de arquivo OFX",
      badge: null,
    },
  ];

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-xl md:text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">Importações</h1>
            <p className="text-muted-foreground mt-1">
              Importe dados de diferentes fontes
            </p>
          </div>
          <Button variant="outline" className="gap-2" onClick={handleExportHistory} disabled={isExporting}>
            {isExporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            Exportar Histórico
          </Button>
        </motion.div>

        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-1 gap-4">
          {importTypes.map((type, index) => {
            const Icon = type.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ y: -4 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Card className="hover:shadow-xl transition-shadow cursor-pointer group h-full border-border/50 hover:border-primary/30">
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 group-hover:from-primary/20 group-hover:to-primary/10 transition-all">
                        <Icon className="h-8 w-8 text-primary" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          {type.title}
                          {type.badge && (
                            <Badge variant="secondary">{type.badge}</Badge>
                          )}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground mt-2">
                          {type.description}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full gap-2 shadow-lg shadow-primary/20"
                      onClick={() => {
                        if (index === 0) {
                          setShowCSVDialog(true);
                        } else {
                          toast({
                            title: "Em breve",
                            description: "Esta funcionalidade estará disponível em breve",
                          });
                        }
                      }}
                    >
                      <Upload className="h-4 w-4" />
                      Importar
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle>Histórico de Importações</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <div className="mb-4 inline-flex p-4 rounded-full bg-primary/10">
                  <FileSpreadsheet className="h-12 w-12 text-primary" />
                </div>
                <p className="text-lg font-semibold text-foreground">Nenhuma importação realizada ainda</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Importar arquivo externo
                </p>
                <p className="text-sm text-muted-foreground">
                  Clique em uma das opções acima para realizar a primeira importação
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <Dialog open={showCSVDialog} onOpenChange={setShowCSVDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Importar Transações - CSV</DialogTitle>
              <DialogDescription>
                Faça upload de um arquivo CSV com suas transações. O arquivo deve conter as colunas: description, amount, type, date, category
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="csv-file">Arquivo CSV</Label>
                <Input
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  onChange={handleCSVFileSelect}
                  disabled={isProcessing}
                />
              </div>

              {csvPreview && (
                <div className="space-y-4">
                  <Alert>
                    <CheckCircle2 className="h-4 w-4" />
                    <AlertDescription>
                      Arquivo carregado: {csvPreview.totalRows} transações encontradas. Mostrando preview das primeiras 10.
                    </AlertDescription>
                  </Alert>

                  <div className="border rounded-lg overflow-auto max-h-96">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {csvPreview.headers.map((header, i) => (
                            <TableHead key={i}>{header}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {csvPreview.rows.map((row, i) => (
                          <TableRow key={i}>
                            {row.map((cell, j) => (
                              <TableCell key={j}>{cell}</TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {validationErrors.length > 0 && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <div className="font-semibold mb-2">Erros de validação:</div>
                        <ul className="list-disc list-inside space-y-1">
                          {validationErrors.slice(0, 5).map((error, i) => (
                            <li key={i} className="text-sm">{error}</li>
                          ))}
                          {validationErrors.length > 5 && (
                            <li className="text-sm font-semibold">
                              ... e mais {validationErrors.length - 5} erros
                            </li>
                          )}
                        </ul>
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex gap-2 justify-end">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setShowCSVDialog(false);
                        setCSVFile(null);
                        setCSVPreview(null);
                        setValidationErrors([]);
                      }}
                      disabled={isProcessing}
                    >
                      Cancelar
                    </Button>
                    <Button
                      onClick={handleImportCSV}
                      disabled={isProcessing || !csvFile}
                    >
                      {isProcessing ? "Importando..." : `Importar ${csvPreview.totalRows} transações`}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </motion.div>
    </AppLayout>
  );
}
