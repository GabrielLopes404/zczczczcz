import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PageContainer } from "@/components/PageContainer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Loader2, Upload, Image, Video, FileText, Trash2, Eye, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MediaItem {
  id: string;
  title: string;
  description: string | null;
  fileName: string;
  fileSize: number;
  mimeType: string;
  mediaType: "image" | "video" | "document";
  url: string;
  thumbnailUrl: string | null;
  width: number | null;
  height: number | null;
  duration: number | null;
  altText: string | null;
  uploadedBy: string;
  isPublic: boolean;
  tags: string[] | null;
  createdAt: string;
  updatedAt: string;
}

export default function OwnerMediaPage() {
  const [selectedType, setSelectedType] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [previewItem, setPreviewItem] = useState<MediaItem | null>(null);
  const [editingItem, setEditingItem] = useState<MediaItem | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: mediaItems = [], isLoading } = useQuery<MediaItem[]>({
    queryKey: ["/api/media/media", selectedType, searchTerm],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedType !== "all") params.append("mediaType", selectedType);
      if (searchTerm) params.append("search", searchTerm);
      
      const res = await fetch(`/api/media/media?${params}`);
      if (!res.ok) throw new Error("Falha ao carregar mídias");
      return res.json();
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/media/media/upload", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Falha ao fazer upload");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media/media"] });
      setUploadDialogOpen(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
      toast({
        title: "Sucesso!",
        description: "Arquivo(s) enviado(s) com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao fazer upload",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<MediaItem> }) => {
      const res = await fetch(`/api/media/media/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Falha ao atualizar mídia");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media/media"] });
      setEditingItem(null);
      toast({
        title: "Sucesso!",
        description: "Mídia atualizada com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao atualizar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/media/media/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Falha ao deletar mídia");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media/media"] });
      toast({
        title: "Sucesso!",
        description: "Mídia deletada com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao deletar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleUpload = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    uploadMutation.mutate(formData);
  };

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingItem) return;

    const formData = new FormData(e.currentTarget);
    const tags = formData.get("tags") as string;
    
    updateMutation.mutate({
      id: editingItem.id,
      data: {
        title: formData.get("title") as string,
        description: formData.get("description") as string,
        altText: formData.get("altText") as string,
        isPublic: formData.get("isPublic") === "true",
        tags: tags ? tags.split(",").map(t => t.trim()) : null,
      },
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  const getMediaIcon = (type: string) => {
    switch (type) {
      case "image": return <Image className="h-4 w-4" />;
      case "video": return <Video className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <PageContainer title="Biblioteca de Mídia">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex gap-4 flex-1 max-w-2xl">
            <Input
              placeholder="Buscar mídias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="image">Imagens</SelectItem>
                <SelectItem value="video">Vídeos</SelectItem>
                <SelectItem value="document">Documentos</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => setUploadDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Fazer Upload
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : mediaItems.length === 0 ? (
          <Alert>
            <AlertDescription>
              Nenhuma mídia encontrada. Faça upload de arquivos para começar.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {mediaItems.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative aspect-video bg-gray-100 flex items-center justify-center">
                  {item.mediaType === "image" ? (
                    <img
                      src={item.url}
                      alt={item.altText || item.title}
                      className="w-full h-full object-cover"
                    />
                  ) : item.mediaType === "video" ? (
                    <video src={item.url} className="w-full h-full object-cover" />
                  ) : (
                    <FileText className="h-12 w-12 text-gray-400" />
                  )}
                  <div className="absolute top-2 right-2 flex gap-2">
                    <Badge variant="secondary" className="bg-white/90">
                      {getMediaIcon(item.mediaType)}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4 space-y-2">
                  <h3 className="font-medium truncate">{item.title}</h3>
                  {item.description && (
                    <p className="text-sm text-gray-500 line-clamp-2">{item.description}</p>
                  )}
                  <div className="flex justify-between items-center text-xs text-gray-500">
                    <span>{formatFileSize(item.fileSize)}</span>
                    <Badge variant={item.isPublic ? "default" : "secondary"}>
                      {item.isPublic ? "Público" : "Privado"}
                    </Badge>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setPreviewItem(item)}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Ver
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingItem(item)}
                    >
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (confirm("Deseja realmente deletar esta mídia?")) {
                          deleteMutation.mutate(item.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
          <DialogContent className="max-w-md">
            <form onSubmit={handleUpload}>
              <DialogHeader>
                <DialogTitle>Fazer Upload de Mídia</DialogTitle>
                <DialogDescription>
                  Envie imagens, vídeos ou documentos para sua biblioteca.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label htmlFor="files">Arquivos *</Label>
                  <Input
                    id="files"
                    name="files"
                    type="file"
                    multiple
                    required
                    ref={fileInputRef}
                    accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Máximo 100MB por arquivo. Até 10 arquivos por vez.
                  </p>
                </div>
                <div>
                  <Label htmlFor="upload-title">Título</Label>
                  <Input id="upload-title" name="title" placeholder="Nome do arquivo" />
                </div>
                <div>
                  <Label htmlFor="upload-description">Descrição</Label>
                  <Textarea
                    id="upload-description"
                    name="description"
                    placeholder="Descreva o conteúdo..."
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch id="upload-isPublic" name="isPublic" defaultChecked />
                  <Label htmlFor="upload-isPublic">Tornar público</Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setUploadDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={uploadMutation.isPending}>
                  {uploadMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Fazer Upload
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {editingItem && (
          <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
            <DialogContent className="max-w-md">
              <form onSubmit={handleUpdate}>
                <DialogHeader>
                  <DialogTitle>Editar Mídia</DialogTitle>
                  <DialogDescription>
                    Atualize as informações da mídia.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="edit-title">Título *</Label>
                    <Input
                      id="edit-title"
                      name="title"
                      defaultValue={editingItem.title}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-description">Descrição</Label>
                    <Textarea
                      id="edit-description"
                      name="description"
                      defaultValue={editingItem.description || ""}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-altText">Texto Alternativo</Label>
                    <Input
                      id="edit-altText"
                      name="altText"
                      defaultValue={editingItem.altText || ""}
                      placeholder="Para acessibilidade"
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-tags">Tags (separadas por vírgula)</Label>
                    <Input
                      id="edit-tags"
                      name="tags"
                      defaultValue={editingItem.tags?.join(", ") || ""}
                      placeholder="produto, marketing, banner"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="edit-isPublic"
                      name="isPublic"
                      defaultChecked={editingItem.isPublic}
                    />
                    <Label htmlFor="edit-isPublic">Tornar público</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setEditingItem(null)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={updateMutation.isPending}>
                    {updateMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Salvar
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}

        {previewItem && (
          <Dialog open={!!previewItem} onOpenChange={() => setPreviewItem(null)}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
              <DialogHeader>
                <DialogTitle>{previewItem.title}</DialogTitle>
                <DialogDescription>{previewItem.fileName}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="bg-gray-100 rounded-lg p-4 flex items-center justify-center">
                  {previewItem.mediaType === "image" ? (
                    <img
                      src={previewItem.url}
                      alt={previewItem.altText || previewItem.title}
                      className="max-w-full h-auto max-h-96 rounded"
                    />
                  ) : previewItem.mediaType === "video" ? (
                    <video src={previewItem.url} controls className="max-w-full h-auto max-h-96 rounded" />
                  ) : (
                    <a href={previewItem.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                      Abrir documento em nova aba
                    </a>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Tipo:</strong> {previewItem.mimeType}
                  </div>
                  <div>
                    <strong>Tamanho:</strong> {formatFileSize(previewItem.fileSize)}
                  </div>
                  {previewItem.width && (
                    <div>
                      <strong>Dimensões:</strong> {previewItem.width} x {previewItem.height}
                    </div>
                  )}
                  {previewItem.duration && (
                    <div>
                      <strong>Duração:</strong> {Math.floor(previewItem.duration / 60)}m {previewItem.duration % 60}s
                    </div>
                  )}
                  <div>
                    <strong>Visibilidade:</strong> {previewItem.isPublic ? "Público" : "Privado"}
                  </div>
                  <div>
                    <strong>Criado em:</strong> {new Date(previewItem.createdAt).toLocaleDateString()}
                  </div>
                </div>
                {previewItem.description && (
                  <div>
                    <strong>Descrição:</strong>
                    <p className="mt-1 text-gray-600">{previewItem.description}</p>
                  </div>
                )}
                {previewItem.tags && previewItem.tags.length > 0 && (
                  <div>
                    <strong>Tags:</strong>
                    <div className="flex gap-2 mt-1 flex-wrap">
                      {previewItem.tags.map((tag, i) => (
                        <Badge key={i} variant="secondary">{tag}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button onClick={() => setPreviewItem(null)}>Fechar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </PageContainer>
  );
}
