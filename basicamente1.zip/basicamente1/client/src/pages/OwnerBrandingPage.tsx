import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save, Palette, Type, Image as ImageIcon, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface BrandingConfig {
  id: string;
  platformName: string;
  logo: string | null;
  favicon: string | null;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  supportEmail: string | null;
  supportPhone: string | null;
  companyAddress: string | null;
  customDomain: string | null;
  footerText: string | null;
  socialLinks: string | null;
  analyticsId: string | null;
}

export default function OwnerBrandingPage() {
  const [csrfToken, setCsrfToken] = useState("");
  const [formData, setFormData] = useState<Partial<BrandingConfig>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  const { data: branding, isLoading } = useQuery({
    queryKey: ["/api/owner/branding"],
    queryFn: async () => {
      const res = await fetch("/api/owner/branding", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch branding");
      return res.json();
    },
  });

  useEffect(() => {
    if (branding) {
      setFormData(branding);
    }
  }, [branding]);

  const updateMutation = useMutation({
    mutationFn: async (data: Partial<BrandingConfig>) => {
      const res = await fetch("/api/owner/branding", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update branding");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/owner/branding"] });
      toast({
        title: "Configurações salvas",
        description: "As configurações de branding foram atualizadas com sucesso",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao salvar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleChange = (field: keyof BrandingConfig, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="ml-2 text-muted-foreground">Carregando configurações...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-xl md:text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Configurações de Branding
          </h1>
          <p className="text-muted-foreground mt-1">
            Personalize a aparência e identidade visual da plataforma
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="general" className="space-y-4">
            <TabsList>
              <TabsTrigger value="general">
                <Globe className="h-4 w-4 mr-2" />
                Geral
              </TabsTrigger>
              <TabsTrigger value="colors">
                <Palette className="h-4 w-4 mr-2" />
                Cores
              </TabsTrigger>
              <TabsTrigger value="images">
                <ImageIcon className="h-4 w-4 mr-2" />
                Imagens
              </TabsTrigger>
              <TabsTrigger value="typography">
                <Type className="h-4 w-4 mr-2" />
                Tipografia
              </TabsTrigger>
            </TabsList>

            <TabsContent value="general">
              <Card>
                <CardHeader>
                  <CardTitle>Informações Gerais</CardTitle>
                  <CardDescription>
                    Configure o nome e informações de contato da plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="platformName">Nome da Plataforma</Label>
                    <Input
                      id="platformName"
                      value={formData.platformName || ""}
                      onChange={(e) => handleChange("platformName", e.target.value)}
                      placeholder="LUCREI"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supportEmail">Email de Suporte</Label>
                    <Input
                      id="supportEmail"
                      type="email"
                      value={formData.supportEmail || ""}
                      onChange={(e) => handleChange("supportEmail", e.target.value)}
                      placeholder="suporte@exemplo.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supportPhone">Telefone de Suporte</Label>
                    <Input
                      id="supportPhone"
                      value={formData.supportPhone || ""}
                      onChange={(e) => handleChange("supportPhone", e.target.value)}
                      placeholder="(11) 1234-5678"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="companyAddress">Endereço da Empresa</Label>
                    <Textarea
                      id="companyAddress"
                      value={formData.companyAddress || ""}
                      onChange={(e) => handleChange("companyAddress", e.target.value)}
                      placeholder="Rua Exemplo, 123 - São Paulo, SP"
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customDomain">Domínio Personalizado</Label>
                    <Input
                      id="customDomain"
                      value={formData.customDomain || ""}
                      onChange={(e) => handleChange("customDomain", e.target.value)}
                      placeholder="app.seudominio.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="footerText">Texto do Rodapé</Label>
                    <Input
                      id="footerText"
                      value={formData.footerText || ""}
                      onChange={(e) => handleChange("footerText", e.target.value)}
                      placeholder="© 2025 Sua Empresa. Todos os direitos reservados."
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="colors">
              <Card>
                <CardHeader>
                  <CardTitle>Esquema de Cores</CardTitle>
                  <CardDescription>
                    Defina as cores principais da plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="primaryColor">Cor Primária</Label>
                      <div className="flex gap-2">
                        <Input
                          id="primaryColor"
                          type="color"
                          value={formData.primaryColor || "#8B5CF6"}
                          onChange={(e) => handleChange("primaryColor", e.target.value)}
                          className="w-20 h-10"
                        />
                        <Input
                          value={formData.primaryColor || "#8B5CF6"}
                          onChange={(e) => handleChange("primaryColor", e.target.value)}
                          placeholder="#8B5CF6"
                          className="flex-1"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="secondaryColor">Cor Secundária</Label>
                      <div className="flex gap-2">
                        <Input
                          id="secondaryColor"
                          type="color"
                          value={formData.secondaryColor || "#06B6D4"}
                          onChange={(e) => handleChange("secondaryColor", e.target.value)}
                          className="w-20 h-10"
                        />
                        <Input
                          value={formData.secondaryColor || "#06B6D4"}
                          onChange={(e) => handleChange("secondaryColor", e.target.value)}
                          placeholder="#06B6D4"
                          className="flex-1"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="accentColor">Cor de Destaque</Label>
                      <div className="flex gap-2">
                        <Input
                          id="accentColor"
                          type="color"
                          value={formData.accentColor || "#10B981"}
                          onChange={(e) => handleChange("accentColor", e.target.value)}
                          className="w-20 h-10"
                        />
                        <Input
                          value={formData.accentColor || "#10B981"}
                          onChange={(e) => handleChange("accentColor", e.target.value)}
                          placeholder="#10B981"
                          className="flex-1"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="p-4 border rounded-lg space-y-2">
                    <p className="text-sm font-medium">Prévia das Cores:</p>
                    <div className="flex gap-2">
                      <div
                        className="w-20 h-20 rounded-lg shadow-md"
                        style={{ backgroundColor: formData.primaryColor }}
                      />
                      <div
                        className="w-20 h-20 rounded-lg shadow-md"
                        style={{ backgroundColor: formData.secondaryColor }}
                      />
                      <div
                        className="w-20 h-20 rounded-lg shadow-md"
                        style={{ backgroundColor: formData.accentColor }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="images">
              <Card>
                <CardHeader>
                  <CardTitle>Logotipos e Ícones</CardTitle>
                  <CardDescription>
                    Configure as imagens da plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="logo">URL do Logo</Label>
                    <Input
                      id="logo"
                      value={formData.logo || ""}
                      onChange={(e) => handleChange("logo", e.target.value)}
                      placeholder="https://exemplo.com/logo.png"
                    />
                    {formData.logo && (
                      <div className="mt-2">
                        <img src={formData.logo} alt="Logo" className="h-16 object-contain" />
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="favicon">URL do Favicon</Label>
                    <Input
                      id="favicon"
                      value={formData.favicon || ""}
                      onChange={(e) => handleChange("favicon", e.target.value)}
                      placeholder="https://exemplo.com/favicon.ico"
                    />
                    {formData.favicon && (
                      <div className="mt-2">
                        <img src={formData.favicon} alt="Favicon" className="h-8 object-contain" />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="typography">
              <Card>
                <CardHeader>
                  <CardTitle>Tipografia</CardTitle>
                  <CardDescription>
                    Configure a fonte principal da plataforma
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fontFamily">Família de Fonte</Label>
                    <Input
                      id="fontFamily"
                      value={formData.fontFamily || ""}
                      onChange={(e) => handleChange("fontFamily", e.target.value)}
                      placeholder="Inter, Roboto, Arial, sans-serif"
                    />
                    <p className="text-sm text-muted-foreground">
                      Use fontes do Google Fonts ou fontes do sistema
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <p
                      className="text-lg"
                      style={{ fontFamily: formData.fontFamily || "Inter" }}
                    >
                      Prévia do texto com a fonte selecionada
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-2 mt-6">
            <Button
              type="submit"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
