import { useState } from "react";
import { Button } from "@/components/ui/button";
import { X, Sparkles, AlertTriangle } from "lucide-react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

interface TrialBannerProps {
  daysLeft: number;
  isTrialing: boolean;
  hasActiveSubscription: boolean;
}

export default function TrialBanner({ daysLeft, isTrialing, hasActiveSubscription }: TrialBannerProps) {
  const [dismissed, setDismissed] = useState(false);
  const [, setLocation] = useLocation();

  if (dismissed || hasActiveSubscription || (!isTrialing && daysLeft <= 0)) {
    return null;
  }

  const showWarning = daysLeft <= 3;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
        className={`relative overflow-hidden border-b ${
          showWarning 
            ? "bg-gradient-to-r from-orange-500/10 via-red-500/10 to-orange-500/10 border-orange-200/20 dark:from-orange-500/20 dark:via-red-500/20 dark:to-orange-500/20 dark:border-orange-500/30"
            : "bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 border-primary/20"
        }`}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-shimmer" 
             style={{ 
               backgroundSize: '200% 100%',
               animation: 'shimmer 3s infinite linear'
             }} 
        />
        
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6">
          <div className="flex items-center justify-between gap-2 py-2 sm:py-2.5">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
              <div className={`flex-shrink-0 ${
                showWarning ? "text-orange-600 dark:text-orange-400" : "text-primary"
              }`}>
                {showWarning ? (
                  <AlertTriangle className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
                ) : (
                  <Sparkles className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
                )}
              </div>
              
              <div className="min-w-0 flex-1">
                <p className={`text-xs sm:text-sm font-medium truncate ${
                  showWarning 
                    ? "text-orange-900 dark:text-orange-100" 
                    : "text-foreground/90"
                }`}>
                  {isTrialing ? (
                    <span className="inline-flex items-center gap-1 flex-wrap">
                      <span className="hidden sm:inline">Período de avaliação:</span>
                      <span className="sm:hidden">Trial:</span>
                      <span className={`font-bold ${
                        showWarning 
                          ? "text-orange-700 dark:text-orange-300" 
                          : "text-primary"
                      }`}>
                        {daysLeft} {daysLeft === 1 ? 'dia' : 'dias'}
                      </span>
                      <span className="hidden md:inline text-muted-foreground">restantes</span>
                    </span>
                  ) : (
                    <span>Trial expirado - Assine para continuar</span>
                  )}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              <Button 
                size="sm"
                onClick={() => setLocation("/app/subscription")}
                className={`h-7 px-2.5 sm:px-3 text-xs font-semibold shadow-sm ${
                  showWarning
                    ? "bg-orange-600 hover:bg-orange-700 text-white dark:bg-orange-500 dark:hover:bg-orange-600"
                    : "bg-primary hover:bg-primary/90 text-primary-foreground"
                }`}
              >
                <span className="hidden sm:inline">Assinar Agora</span>
                <span className="sm:hidden">Assinar</span>
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setDismissed(true)}
                className={`h-7 w-7 flex-shrink-0 ${
                  showWarning
                    ? "text-orange-700 hover:bg-orange-100 dark:text-orange-300 dark:hover:bg-orange-500/20"
                    : "text-muted-foreground hover:bg-accent"
                }`}
                aria-label="Fechar"
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
