# LUCREI - Financial Management SaaS Platform

## Overview

LUCREI is a comprehensive financial management SaaS platform designed for small and medium-sized businesses in the Brazilian market. The system provides complete control over revenues, expenses, customer management, invoicing, and financial reporting with role-based access control (RBAC) supporting three user levels: OWNER, ADMIN, and CUSTOMER.

The platform features a modern, responsive design with mobile-first principles, subscription-based billing through Stripe, and a content management system for dynamic site customization.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18+ with TypeScript for type safety
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and caching
- Shadcn/ui components built on Radix UI primitives
- Tailwind CSS with custom design tokens for consistent styling
- Framer Motion for animations and micro-interactions
- i18next for internationalization (pt-BR primary language)

**Design System:**
- Mobile-first responsive design with breakpoints: mobile (<640px), tablet (640-1024px), desktop (≥1024px)
- Custom color scheme system with support for purple, blue, green, orange, and pink themes
- Consistent spacing scale: xs(8px), sm(16px), md(24px), lg(32px), xl(48px)
- Typography hierarchy optimized for readability across devices
- Dark/light theme support via next-themes

**State Management:**
- Server state: TanStack Query with 5-minute stale time for metrics, 10-minute for categories
- Authentication state: Session-based with Passport.js
- UI state: React hooks and context where needed
- Form validation: React Hook Form with Zod schemas

**Error Handling:**
- React Error Boundaries for component-level error isolation
- Sentry integration for production error tracking and monitoring
- Custom error fallback components with user-friendly messages
- Graceful degradation for failed API calls

### Backend Architecture

**Core Framework:**
- Express.js server with TypeScript
- Session-based authentication using Passport.js with local strategy
- PostgreSQL session store via connect-pg-simple
- CSRF protection on all mutating endpoints

**Authentication & Authorization:**
- **RBAC Implementation:** Three-tier role system (OWNER > ADMIN > CUSTOMER)
- **Session Management:** Server-side sessions with PostgreSQL storage, multi-device support with session tracking
- **Password Security:** bcrypt hashing with 12 rounds, password strength validation
- **2FA Support:** TOTP-based two-factor authentication (optional)
- **Email Verification:** Token-based email verification flow with 24-hour expiration
- **API Key Authentication:** Alternative authentication for programmatic access

**Role Permissions:**
- **OWNER:** Full system access including plan management, branding customization, audit logs, user promotion/demotion, organization deletion
- **ADMIN:** User management (invite, view, remove), ticket management, reports access, cannot modify OWNER or other ADMINs
- **CUSTOMER:** Personal data access only, can create transactions/customers within their scope

**Middleware Pipeline:**
- Rate limiting (express-rate-limit) with endpoint-specific configurations
- Helmet.js for security headers
- CORS configuration for cross-origin requests
- Request logging with Winston logger
- Pagination utilities (max 100 items per page)

**API Design:**
- RESTful endpoints with consistent response formats
- Pagination support with metadata (total, page, hasNext, hasPrev)
- Input validation using Zod schemas
- Error responses with actionable messages
- CSRF tokens in cookies for state-changing operations

### Data Storage Solutions

**Primary Database:**
- PostgreSQL (Neon serverless recommended for production)
- Drizzle ORM for type-safe database queries
- Schema-first approach with versioned migrations

**Database Schema Highlights:**
- Organizations table: Multi-tenant architecture root
- Users: Links to organization with role-based permissions
- Customers: Business contacts with document validation (CPF/CNPJ)
- Transactions: Double-entry bookkeeping with categories, tags, cost centers
- Invoices: Complete billing cycle tracking with status workflow
- Subscriptions: Stripe integration for SaaS billing
- Audit logs: Immutable append-only trail for compliance
- Media library: File metadata with version control

**Caching Strategy:**
- Memoization using memoizee for expensive computations
- Metrics cache: 5-minute TTL
- Categories/bank accounts: 10-minute TTL
- User preferences: 15-minute TTL
- Client-side caching via TanStack Query

**File Storage:**
- Local filesystem storage in production (uploads directory)
- Multer middleware for multipart/form-data handling
- 100MB max file size limit
- MIME type validation for security
- Unique filename generation with crypto.randomBytes

### Authentication and Authorization Mechanisms

**Session Flow:**
1. User submits credentials via POST /api/auth/login
2. Passport.js verifies credentials against database
3. Session created and stored in PostgreSQL
4. Session cookie sent to client (httpOnly, secure in production, sameSite: strict)
5. Subsequent requests include session cookie for authentication
6. Middleware checks req.user populated by Passport deserializeUser

**Registration Flow:**
1. User submits registration form with organization details
2. Backend validates uniqueness and password strength
3. Organization created (or user joins existing via invite)
4. User created with OWNER role (or CUSTOMER if invited)
5. Verification email sent via Resend
6. Auto-login after registration
7. Email verification required for full feature access

**RBAC Enforcement:**
- Middleware functions: requireCustomer, requireAdmin, requireOwner
- Resource ownership checks before operations
- Organization-scoped queries (all data filtered by organizationId)
- Audit logging for sensitive operations

**Security Features:**
- Rate limiting: Auth endpoints (5/15min), API keys (3/hour), file uploads (20/15min)
- CSRF protection on all state-changing requests
- Password validation: min 8 chars, uppercase, lowercase, number, special char
- Document validation for Brazilian CPF/CNPJ
- SQL injection prevention via parameterized queries (Drizzle ORM)
- XSS protection via input sanitization and Content Security Policy headers

### External Dependencies

**Payment Processing:**
- Stripe API for subscription management and payments
- Webhook handling for payment events (invoice.paid, subscription.updated, etc.)
- Customer portal for self-service billing
- Price IDs configured per plan (starter, business, enterprise) and billing period (monthly, yearly)

**Email Service:**
- Resend API for transactional emails
- Templates for: verification, password reset, invoice notifications, subscription alerts
- Development mode: Console logging instead of sending
- Configurable sender address via EMAIL_FROM environment variable

**Error Tracking:**
- Sentry for production error monitoring and performance tracking
- Client-side (React) and server-side (Node.js) integration
- Automatic error capturing with context (user info, request details)
- Sensitive data sanitization before sending (passwords, tokens, cookies removed)
- Breadcrumb trail for debugging

**Content Management:**
- Database-driven CMS for site pages and content blocks
- **Media Library System (NEW - Nov 2025):**
  - Multi-tenant media storage with organizationId scoping for complete data isolation
  - Support for images, videos (up to 100MB), and documents
  - Full CRUD operations: upload, list, update, delete with RBAC enforcement
  - Metadata management: title, description, alt text, tags, visibility (public/private)
  - Advanced filtering and search capabilities
  - Schema-validated uploads using Zod for data integrity
  - Owner-only deletion rights for security
  - Audit logging for all media operations
  - Comprehensive UI with upload, preview, edit, and search functionality
- **Content Versioning System (NEW - Nov 2025):**
  - Complete version history for all content entities (pages, blocks, branding)
  - Multi-tenant versioning with organizationId isolation
  - Incremental version numbering per entity
  - Full content snapshots stored as JSON
  - Change descriptions for audit trail
  - Rollback functionality to restore previous versions
  - Published/unpublished version states
  - Owner-only rollback permissions
  - Audit logging for versioning operations
- Branding configuration (logo, colors, custom CSS)
- Dedicated Owner pages: /app/owner/media for media management, /app/owner/content for CMS

**Testing Infrastructure:**
- Vitest for unit and integration tests
- Playwright for end-to-end testing across browsers
- Happy-DOM for React component testing environment
- Test coverage reporting with V8 provider

**Development Tools:**
- Vite for fast development server and optimized production builds
- esbuild for server bundling
- Drizzle Kit for database migrations
- ESLint and Prettier for code quality (implied by structure)

**Third-Party Libraries:**
- bcryptjs: Password hashing
- PDFKit: PDF report generation
- XLSX: Excel export functionality
- json2csv: CSV data export
- otplib: 2FA token generation
- qrcode: QR code generation for 2FA setup
- UA-Parser: User agent parsing for session tracking